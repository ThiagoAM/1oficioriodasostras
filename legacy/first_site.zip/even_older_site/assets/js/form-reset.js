window.onload = function () {
  // Reset the form fields when the page loads
  document.getElementById("message-form").reset();
};
